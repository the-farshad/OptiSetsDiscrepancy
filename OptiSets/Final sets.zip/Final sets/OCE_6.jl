x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:7
And data, a 8-element Vector{Float64}:
 0.0
 0.17359275704289986
 0.25250808018029414
 0.45911091855882064
 0.7144809579840743
 0.9210836800105608
 1.0
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:7
And data, a 8-element Vector{Float64}:
 0.0
 0.10812780768214135
 0.1932948587529153
 0.4162630696079818
 0.691863335405277
 0.9148324491215742
 1.0
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:7
    Dimension 2, 0:7
And data, a 8×8 Matrix{Float64}:
 0.0   0.0   0.0   0.0   0.0   0.0   0.0  0.0
 0.0  -0.0  -0.0  -0.0  -0.0  -0.0   1.0  1.0
 0.0   0.0   1.0  -0.0   0.0  -0.0  -0.0  0.0
 0.0  -0.0   0.0  -0.0   1.0   0.0   0.0  0.0
 0.0  -0.0  -0.0   1.0   0.0  -0.0  -0.0  0.0
 0.0  -0.0  -0.0   0.0   0.0   1.0  -0.0  0.0
 0.0   1.0  -0.0  -0.0  -0.0  -0.0  -0.0  0.0
 0.0   1.0   0.0   0.0   0.0   0.0   0.0  0.0
