x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:7
And data, a 8-element Vector{Float64}:
 0.0
 0.08461560407849761
 0.26501541757173525
 0.4048180942654096
 0.5491762981909812
 0.7674135006238992
 0.9162948057879378
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:7
And data, a 8-element Vector{Float64}:
 0.0
 0.030744592276794488
 0.17962610135542245
 0.39786309987375096
 0.5300110407545026
 0.6820240040070036
 0.8624247027024576
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:7
    Dimension 2, 0:7
And data, a 8×8 Matrix{Float64}:
 0.0  0.0  0.0  0.0  0.0  0.0  0.0  0.0
 0.0  0.0  0.0  0.0  1.0  0.0  0.0  1.0
 0.0  0.0  1.0  0.0  0.0  0.0  0.0  0.0
 0.0  0.0  0.0  0.0  0.0  0.0  1.0  0.0
 0.0  0.0  0.0  1.0  0.0  0.0  0.0  0.0
 0.0  0.0  0.0  0.0  0.0  1.0  0.0  0.0
 0.0  1.0  0.0  0.0  0.0  0.0  0.0  0.0
 0.0  1.0  0.0  0.0  0.0  0.0  0.0  0.0
