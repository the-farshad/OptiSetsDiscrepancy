x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:6
And data, a 7-element Vector{Float64}:
 0.0
 0.05656671219920262
 0.2783825361539624
 0.45791819568445025
 0.6609381433739558
 0.881504850545856
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:6
And data, a 7-element Vector{Float64}:
 0.0
 0.019290316325975145
 0.2017900285749781
 0.4442284546726285
 0.6267281669216315
 0.8223664680506811
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:6
    Dimension 2, 0:6
And data, a 7×7 Matrix{Float64}:
 0.0  0.0  0.0  0.0  0.0  0.0  0.0
 0.0  0.0  0.0  0.0  1.0  0.0  1.0
 0.0  0.0  1.0  0.0  0.0  0.0  0.0
 0.0  0.0  0.0  0.0  0.0  1.0  0.0
 0.0  0.0  0.0  1.0  0.0  0.0  0.0
 0.0  1.0  0.0  0.0  0.0  0.0  0.0
 0.0  1.0  0.0  0.0  0.0  0.0  0.0
