x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:2
And data, a 3-element Vector{Float64}:
 0.0
 0.0
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:2
And data, a 3-element Vector{Float64}:
 0.0
 0.0
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:2
    Dimension 2, 0:2
And data, a 3×3 Matrix{Float64}:
 0.0  0.0  0.0
 0.0  1.0  1.0
 0.0  1.0  0.0
