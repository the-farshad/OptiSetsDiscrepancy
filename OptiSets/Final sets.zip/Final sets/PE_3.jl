x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:4
And data, a 5-element Vector{Float64}:
 0.0
 0.08323851379675912
 0.35340929504807367
 0.7012707589694798
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:4
And data, a 5-element Vector{Float64}:
 0.0
 0.09740789002382315
 0.45916066096583874
 0.7154401351965437
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:4
    Dimension 2, 0:4
And data, a 5×5 Matrix{Float64}:
 0.0  0.0   0.0   0.0  0.0
 0.0  0.0  -0.0   1.0  1.0
 0.0  0.0   1.0  -0.0  0.0
 0.0  1.0  -0.0   0.0  0.0
 0.0  1.0   0.0   0.0  0.0
