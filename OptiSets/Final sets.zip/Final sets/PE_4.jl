x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:5
And data, a 6-element Vector{Float64}:
 0.0
 0.22712168565880383
 0.39378919879877816
 0.7271207135190767
 0.8937885223659834
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:5
And data, a 6-element Vector{Float64}:
 0.0
 0.08465756741665208
 0.3346575674166521
 0.5846571862703654
 0.8346568909838573
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:5
    Dimension 2, 0:5
And data, a 6×6 Matrix{Float64}:
 0.0   0.0   0.0   0.0   0.0  0.0
 0.0   0.0   1.0   0.0  -0.0  1.0
 0.0  -0.0  -0.0  -0.0   1.0  0.0
 0.0  -0.0   0.0   1.0   0.0  0.0
 0.0   1.0  -0.0  -0.0  -0.0  0.0
 0.0   1.0   0.0   0.0   0.0  0.0
