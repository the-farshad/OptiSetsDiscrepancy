x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:3
And data, a 4-element Vector{Float64}:
 1.0
 0.6180339877415213
 0.6180339877415213
 1.0