x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:3
And data, a 4-element Vector{Float64}:
 1.0
 1.0
 1.0
 1.0