x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:6
And data, a 7-element Vector{Float64}:
 0.0
 0.07845256954963739
 0.2134123993964695
 0.5397499918903705
 0.8650397660489093
 1.0
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:6
And data, a 7-element Vector{Float64}:
 0.0
 0.23721017223385552
 0.3489206768691103
 0.6181714199485974
 0.8882900379386537
 1.0
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:6
    Dimension 2, 0:6
And data, a 7×7 Matrix{Float64}:
 0.0   0.0   0.0   0.0   0.0   0.0  0.0
 0.0  -0.0  -0.0  -0.0  -0.0   1.0  1.0
 0.0  -0.0   1.0  -0.0   0.0  -0.0  0.0
 0.0   0.0  -0.0   1.0  -0.0  -0.0  0.0
 0.0  -0.0   0.0  -0.0   1.0  -0.0  0.0
 0.0   1.0  -0.0   0.0   0.0   0.0  0.0
 0.0   1.0   0.0   0.0   0.0   0.0  0.0
