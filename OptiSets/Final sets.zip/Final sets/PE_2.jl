x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:3
And data, a 4-element Vector{Float64}:
 0.0
 0.2262258284893024
 0.7263130434387931
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:3
And data, a 4-element Vector{Float64}:
 0.0
 0.19220399359596585
 0.6922912085454567
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:3
    Dimension 2, 0:3
And data, a 4×4 Matrix{Float64}:
 0.0  0.0   0.0  0.0
 0.0  0.0   1.0  1.0
 0.0  1.0  -0.0  0.0
 0.0  1.0   0.0  0.0
