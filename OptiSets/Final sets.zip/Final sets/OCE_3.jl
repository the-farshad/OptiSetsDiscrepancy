x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:4
And data, a 5-element Vector{Float64}:
 0.0
 0.09137796864282205
 0.5457565847795727
 1.0
 1.0
y = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:4
And data, a 5-element Vector{Float64}:
 0.0
 0.1195467303154547
 0.5598391233576483
 1.0
 1.0
a = 2-dimensional DenseAxisArray{Float64,2,...} with index sets:
    Dimension 1, 0:4
    Dimension 2, 0:4
And data, a 5×5 Matrix{Float64}:
 0.0   0.0   0.0   0.0  0.0
 0.0   0.0  -0.0   1.0  1.0
 0.0  -0.0   1.0   0.0  0.0
 0.0   1.0  -0.0  -0.0  0.0
 0.0   1.0   0.0   0.0  0.0
