x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:7
And data, a 8-element Vector{Float64}:
 1.0
 0.33333333333333315
 0.33333333333333315
 0.6666666666666664
 0.6666666666666667
 1.0
 0.33333333333333315
 1.0