x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:5
And data, a 6-element Vector{Float64}:
 1.0
 0.5
 0.5
 1.0
 0.5
 1.0