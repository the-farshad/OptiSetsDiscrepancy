x = 1-dimensional DenseAxisArray{Float64,1,...} with index sets:
    Dimension 1, 0:9
And data, a 10-element Vector{Float64}:
 1.0
 0.25
 0.25
 0.5
 0.5
 0.75
 0.75
 1.0
 1.0
 1.0